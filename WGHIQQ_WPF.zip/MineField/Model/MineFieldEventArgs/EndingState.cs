﻿namespace MineField.Model.MineFieldEventArgs
{
    public enum EndingState
    {
        FirstPlayerWon,
        SecondPlayerWon,
        ItWasATie
    }
}
