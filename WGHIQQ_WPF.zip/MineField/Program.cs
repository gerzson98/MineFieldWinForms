﻿namespace MineField
{
    internal class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
        }
    }
}