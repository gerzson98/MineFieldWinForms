﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MineField.Persistence
{
    public class MineFieldDataException : Exception
    {
        public MineFieldDataException() { }
    }
}
